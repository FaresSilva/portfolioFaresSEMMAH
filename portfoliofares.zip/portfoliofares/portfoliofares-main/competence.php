﻿<?php 
$page = basename(__FILE__);
$title = 'Mes compétences';
require_once './partials/header.php'; 
?>
<section id="en-tete-page">
    <div class="zone clearfix">
        <h1>Compétences</h1>
    </div>
</section>
<section id="competences" class="competences content-section alt-bg-light wow fadeInUp">
    <div class="container eighty">

        <div class="row text-center">
            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">

                <div class="margintopcomp">
                    <h3>Services sous windows serveur</h3>

                    <div class="skillbar clearfix " data-percent="90%">
                        <div class="skillbar-title" style="background: #00FF00;"><span>DHCP</span></div>
                        <div class="skillbar-bar" style="background: #00FF00;"></div>
                        <div class="skill-bar-percent">90%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="80%">
                        <div class="skillbar-title" style="background: #FF0000;"><span>DNS</span></div>
                        <div class="skillbar-bar" style="background: #FF0000;"></div>
                        <div class="skill-bar-percent">80%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="85%">
                        <div class="skillbar-title" style="background: #0000FF;"><span>WEB (IIS)</span></div>
                        <div class="skillbar-bar" style="background: #0000FF;"></div>
                        <div class="skill-bar-percent">85%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="70%">
                        <div class="skillbar-title" style="background: #FF0000;"><span>AD</span></div>
                        <div class="skillbar-bar" style="background: #FF0000;"></div>
                        <div class="skill-bar-percent">70%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="70%">
                        <div class="skillbar-title" style="background: #FF0000; font-size:10px;"><span>Partage de
                                fichiers</span></div>
                        <div class="skillbar-bar" style="background: #FF0000;"></div>
                        <div class="skill-bar-percent">70%</div>
                    </div>
                </div>

                <div class="margintopcomp">
                    <h3>Service sous Debian 8</h3>

                    <div class="skillbar clearfix " data-percent="80%">
                        <div class="skillbar-title" style="background: #FFFF00;"><span>DNS</span></div>
                        <div class="skillbar-bar" style="background: #FFFF00;"></div>
                        <div class="skill-bar-percent">80%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="95%">
                        <div class="skillbar-title" style="background: #FFFF00;"><span>WEB (apache)</span></div>
                        <div class="skillbar-bar" style="background: #FFFF00;"></div>
                        <div class="skill-bar-percent">95%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="90%">
                        <div class="skillbar-title" style="background: #008000;"><span>FTP</span></div>
                        <div class="skillbar-bar" style="background: #008000;"></div>
                        <div class="skill-bar-percent">90%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="70%">
                        <div class="skillbar-title" style="background: #0000FF;"><span>Mail (postfix)</span></div>
                        <div class="skillbar-bar" style="background: #0000FF;"></div>
                        <div class="skill-bar-percent">70%</div>
                    </div>
                </div>

                <div class="margintopcomp">
                    <h3>OS</h3>

                    <div class="skillbar clearfix " data-percent="95%">
                        <div class="skillbar-title" style="background: #0000FF;"><span>Windows7-8-10</span></div>
                        <div class="skillbar-bar" style="background: #0000FF;"></div>
                        <div class="skill-bar-percent">95%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="80%">
                        <div class="skillbar-title" style="background: #00FF00;"><span>Debian</span></div>
                        <div class="skillbar-bar" style="background: #00FF00;"></div>
                        <div class="skill-bar-percent">80%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="65%">
                        <div class="skillbar-title" style="background: #0000FF;"><span>MacOS</span></div>
                        <div class="skillbar-bar" style="background: #0000FF;"></div>
                        <div class="skill-bar-percent">65%</div>
                    </div>
                </div>

            </div>

            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">

                <h3>Supervision de réseau</h3>

                <div class="skillbar clearfix " data-percent="75%">
                    <div class="skillbar-title" style="background: #0080FF;"><span>Nagios</span></div>
                    <div class="skillbar-bar" style="background: #0080FF;"></div>
                    <div class="skill-bar-percent">75%</div>
                </div>

                <div class="margintopcomp">
                    <h3>Redondance de services</h3>

                    <div class="skillbar clearfix " data-percent="80%">
                        <div class="skillbar-title" style="background: #FFFF00;"><span>DHCP</span></div>
                        <div class="skillbar-bar" style="background: #FFFF00;"></div>
                        <div class="skill-bar-percent">80%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="70%">
                        <div class="skillbar-title" style="background: #FFFF00;"><span>DNS</span></div>
                        <div class="skillbar-bar" style="background: #FFFF00;"></div>
                        <div class="skill-bar-percent">70%</div>
                    </div>
                </div>

                <div class="margintopcomp">
                    <h3>Automatisation de tâches</h3>

                    <div class="skillbar clearfix " data-percent="80%">
                        <div class="skillbar-title" style="background: #008000;"><span>BDD</span></div>
                        <div class="skillbar-bar" style="background: #008000;"></div>
                        <div class="skill-bar-percent">80%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="90%">
                        <div class="skillbar-title" style="background: #008000;"><span>Script</span></div>
                        <div class="skillbar-bar" style="background: #008000;"></div>
                        <div class="skill-bar-percent">90%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="65%">
                        <div class="skillbar-title" style="background: #008000;"><span>Powershell</span></div>
                        <div class="skillbar-bar" style="background: #008000;"></div>
                        <div class="skill-bar-percent">65%</div>
                    </div>
                </div>

                <div class="margintopcomp">
                    <h3>Sécurisation de réseau</h3>

                    <div class="skillbar clearfix " data-percent="80%">
                        <div class="skillbar-title" style="background: #008000;"><span>Proxy</span></div>
                        <div class="skillbar-bar" style="background: #008000;"></div>
                        <div class="skill-bar-percent">80%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="70%">
                        <div class="skillbar-title" style="background: #008000;"><span>VPN</span></div>
                        <div class="skillbar-bar" style="background: #008000;"></div>
                        <div class="skill-bar-percent">70%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="75%">
                        <div class="skillbar-title" style="background: #008000;"><span>Pfsense</span></div>
                        <div class="skillbar-bar" style="background: #008000;"></div>
                        <div class="skill-bar-percent">75%</div>
                    </div>
                </div>

            </div>

            <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">

                <h3>Routeur Cisco</h3>

                <div class="skillbar clearfix " data-percent="85%">
                    <div class="skillbar-title" style="background: #008000;"><span>NAT</span></div>
                    <div class="skillbar-bar" style="background: #008000;"></div>
                    <div class="skill-bar-percent">85%</div>
                </div>

                <div class="skillbar clearfix " data-percent="80%">
                    <div class="skillbar-title" style="background: #FF8000;"><span>DHCP</span></div>
                    <div class="skillbar-bar" style="background: #FF8000;"></div>
                    <div class="skill-bar-percent">80%</div>
                </div>

                <div class="skillbar clearfix " data-percent="70%">
                    <div class="skillbar-title" style="background: #0080FF;"><span>HSRP-VRRP</span></div>
                    <div class="skillbar-bar" style="background: #0080FF;"></div>
                    <div class="skill-bar-percent">70%</div>
                </div>

                <div class="skillbar clearfix " data-percent="85%">
                    <div class="skillbar-title" style="background: #0080FF;"><span>RIP-OSPF</span></div>
                    <div class="skillbar-bar" style="background: #0080FF;"></div>
                    <div class="skill-bar-percent">85%</div>
                </div>

                <div class="margintopcomp">
                    <h3>Switch Cisco</h3>

                    <div class="skillbar clearfix " data-percent="85%">
                        <div class="skillbar-title" style="background: #0080FF;"><span>VLAN</span></div>
                        <div class="skillbar-bar" style="background: #0080FF;"></div>
                        <div class="skill-bar-percent">85%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="90%">
                        <div class="skillbar-title" style="background: #0080FF;"><span>VTP</span></div>
                        <div class="skillbar-bar" style="background: #0080FF;"></div>
                        <div class="skill-bar-percent">90%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="90%">
                        <div class="skillbar-title" style="background: #FF8000;"><span>STP</span></div>
                        <div class="skillbar-bar" style="background: #FF8000;"></div>
                        <div class="skill-bar-percent">90%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="80%">
                        <div class="skillbar-title" style="background: #0080FF;"><span>ACL</span></div>
                        <div class="skillbar-bar" style="background: #0080FF;"></div>
                        <div class="skill-bar-percent">80%</div>
                    </div>
                </div>

                <div class="margintopcomp">
                    <h3>Langages</h3>

                    <div class="skillbar clearfix " data-percent="60%">
                        <div class="skillbar-title" style="background: #FF00FF;"><span>PHP</span></div>
                        <div class="skillbar-bar" style="background: #FF00FF;"></div>
                        <div class="skill-bar-percent">60%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="85%">
                        <div class="skillbar-title" style="background: #FF00FF;"><span>HTML</span></div>
                        <div class="skillbar-bar" style="background: #FF00FF;"></div>
                        <div class="skill-bar-percent">85%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="40%">
                        <div class="skillbar-title" style="background: #FF00FF;"><span>JavaScript</span></div>
                        <div class="skillbar-bar" style="background: #FF00FF;"></div>
                        <div class="skill-bar-percent">40%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="90%">
                        <div class="skillbar-title" style="background: #FF00FF;;"><span>CSS</span></div>
                        <div class="skillbar-bar" style="background: #FF00FF;"></div>
                        <div class="skill-bar-percent">90%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="70%">
                        <div class="skillbar-title" style="background: #FF00FF;"><span>Python</span></div>
                        <div class="skillbar-bar" style="background: #FF00FF;"></div>
                        <div class="skill-bar-percent">70%</div>
                    </div>

                    <div class="skillbar clearfix " data-percent="50%">
                        <div class="skillbar-title" style="background: #00FFFF;"><span>SQL</span></div>
                        <div class="skillbar-bar" style="background: #00FFFF;"></div>
                        <div class="skill-bar-percent">50%</div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php require_once './partials/footer.php'; ?>