﻿<?php 
$page = basename(__FILE__);
// A compléter
$title = '';
require_once './partials/header.php'; 
?>

<section id="en-tete-page">
    <div class="zone clearfix">
        <h1>Me contacter</h1>
        <ol class="arborescence">
            <li><a href="index.html">Accueil</a></li>
            <li><a href="#">Me contacter</a></li>
        </ol>
    </div>
</section>
<section id="content">
    <div class="contenu-zone">
        <div class="zone clearfix">
            <div class="postcontent pas-de-margin-bottom">

                <h3 class="title-contact">Me Contacter :</h3>

                <!-- <div class="contact-widget"> -->
                <div class="contact-form-result"></div>

                <form class="pas-de-margin-bottom" id="contact" name="template-contactform"
                    action="https://www.Fares-king.com/contact.php" method="post">
                    <p></p>
                    <div class="form-process"></div>


                    <div class="col_one_third">
                        <label for="nom">Nom <small>*</small></label>
                        <input type="text" id="nom" name="nom" tabindex="1" class="sm-form-control required" />
                    </div>

                    <div class="col_one_third">
                        <label for="email">Email <small>*</small></label>
                        <input type="email" id="email" name="email" tabindex="2"
                            class="required email sm-form-control" />
                    </div>

                    <div class="zone-inf"></div>

                    <div class="col_two_third">
                        <label for="objet">Sujet <small>*</small></label>
                        <input type="text" id="objet" name="objet" tabindex="3" class="required sm-form-control" />
                    </div>

                    <div class="zone-inf"></div>

                    <div class="col_full">
                        <label for="message">Message :<small>*</small></label>
                        <textarea class="required sm-form-control" id="message" name="message" tabindex="4" rows="8"
                            cols="30"></textarea>
                    </div>

                    <div class="col_full">
                        <button class="button button-3d nomargin" type="submit" id="template-contactform-submit"
                            name="envoi" value="Envoyer le formulaire !">Envoyer Message</button>
                    </div>

                </form>

                <!-- </div> -->
            </div>

            <div class="sidebar zone-fin pas-de-margin-bottom">

                <address><strong>Strasbourg</strong><br>France, 67000<br></address>
                <abbr title="Nom - Prénom"><strong>NOM - PRENOM:</strong></abbr> Fares SEMMAH

                <abbr title="Adresse E-Mail"><strong>Email:</strong></abbr> fares67240@gmail.com

                <div class="widget noborder notoppadding">

                </div>

                <div class="widget noborder notoppadding">

                    <a href="https://www.facebook.com/Fares.Fares.184"
                        class="zone-icone-social amin-reduite si-dark anim-facebook">
                        <i class="icone-facebook"></i>
                        <i class="icone-facebook"></i>
                    </a>

                    <a href="https://twitter.com/59FaresFares"
                        class="zone-icone-social amin-reduite si-dark anim-twitter">
                        <i class="icone-twitter"></i>
                        <i class="icone-twitter"></i>
                    </a>

                </div>
            </div>
        </div>
    </div>
</section>
<?php require_once './partials/footer.php'; ?>