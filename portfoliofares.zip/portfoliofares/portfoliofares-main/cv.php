﻿<?php 
$page = basename(__FILE__);
// A compléter
$title = '';
require_once './partials/header.php'; 
?>

<section id="en-tete-page">
    <div class="zone clearfix">
        <h1>CV</h1>
    </div>
</section>

<section id="content">
    <div class="contenu-zone">
        <div class="zone clearfix">
            <div class="zone-milieu zone-fin pas-de-margin-bottom">
                <p style="width: 100%; text-align: center; margin-left: 60px;">
                    <img class="cv" src="fichiers/cv.jpg" width="900" height="1200" />
                </p>
                <ol class="bouton_cv">
                    <li><a href="fichiers/cv.pdf">Lien vers mon CV</a></li>
                </ol>
            </div>
        </div>
    </div>
</section>

<?php require_once './partials/footer.php'; ?>