﻿<?php 
$page = basename(__FILE__);
// A compléter
$title = '';
require_once './partials/header.php'; 
?>

<section id="en-tete-page">
    <div class="zone clearfix">
        <h1>Ma formation</h1>
    </div>
</section>

<section id="content">
    <div class="contenu-zone">
        <div class="zone clearfix">
            <div class="zone-milieu zone-fin pas-de-margin-bottom">
                <p>
                <h3 style="text-align: center;">MA FORMATION</h3>
                </p><br />
                <p>
                <div style="text-indent: 30px;">
                    Le BTS SIO (Services Informatiques aux organisations) a pour vocation de former des prestataires
                    informatiques capables de :</br></br>
                    <div class="indent">
                        - Concevoir et élaborer un service informatique en respectant le cahier des charges</br>
                        - Evaluer et ajuster une solution après sa mise en production</br>
                        - Gérer un patrimoine informatique</br>
                    </div>
                </div>
                </p>
                <br />
                <p>
                <div style="text-indent: 30px;">
                    L’option SLAM (Solutions Logicielles et Applications Métiers) accroît les compétences techniques et
                    relationnelles dans le domaine de :</br></br>
                </div>
                <div class="indent">
                    - La conception, développement, déploiement ainsi que maintenant d'une solution informatique.</br>
                    - La conception et développement de solutions applicatives</br>
                    - Bases de données</br>
                    - La gestion de données numériques</br>
                </div>
            </div>
            </p>
        </div>
    </div>

</section>
<?php require_once './partials/footer.php'; ?>