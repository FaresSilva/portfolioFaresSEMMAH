﻿<?php 
// (__FILE__) récupère le chemin du fichier executer
// La méthode basename permet de récupérer le nom du fichier
$page = basename(__FILE__);
$title = '';
require_once './partials/header.php'; 
?>

<section id="slider" class="amin-multi-slider inter-slider-toucher largeur-max clearfix">
    <div class="amin-multi-slider-inter">
        <div class="zone-slider-toucher zone-slider-toucher-parent">
            <div class="zone-interne-slider">
                <div class="zone-slider style-menu" style="background-image: url('images/slider/bg.jpg')">
                    <div class="zone clearfix">
                        <div class="zone-text-amin-slider zone-text-amin-slider-centre">
                            <h2 id="typed" data-caption-animate="amination-slider-haut" class="slider-text"></h2>
                            <h2 class="slider-text-tel" style="color: whrite; margin-top: -1%;"
                                data-caption-animate="amination-slider-haut">Bienvenue sur mon Portfolio</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <a href="#Intro" data-scrollto="#content" data-offset="100" class="style-menu fleche-bas"><i
                class="icone-fleche-bas infinite animated amination-slider-bas"></i></a>
    </div>
</section>

<section id="content">
    <div class="contenu-zone">
        <div class="zone clearfix">
            <div class="zone-milieu zone-fin pas-de-margin-bottom">
                <h3 id="Intro">Bienvenue sur mon Portfolio !</h3>
                <p>
                <div><br>Je me présente, je m'appelle Fares SEMMAH, je suis actuellement étudiant en deuxième année de
                    BTS SIO (Services Informatiques aux Organisations) option SLAM ( Services informatiques aux
                    organisations solutions logicielles et applications métiers) à Strasbourg dans le Nord. <br><br>Dans
                    le cadre de ma formation, j’ai créé ce site web pour me présenter, détailler ma formation et mes
                    objectifs professionnels.</div>
                <br />
                <br />
                </p>
                <div id="nav_sup">


                </div>
            </div>
        </div>
</section>


<?php require_once './partials/footer.php'; ?>