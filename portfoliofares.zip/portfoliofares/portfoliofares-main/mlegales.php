﻿<?php 
$page = basename(__FILE__);
// A compléter
$title = '';
require_once './partials/header.php'; 
?>

<section id="en-tete-page">
    <div class="zone clearfix">
        <h1>Mentions légales</h1>
    </div>
</section>

<section id="content">
    <div class="contenu-zone">
        <div class="zone clearfix">
            <div class="zone-milieu zone-fin pas-de-margin-bottom">
                <h3>Mentions Légales</h3>
                <p>
                    Les mentions légales obligatoires concernant fares-king.com sont indiquées sur cette page
                    conformément à la loi pour la confiance dans l’économie numérique (LCEN) de juin
                    2004.</br></br></br>
                </p>
                <p>
                <h4>Identification de l’éditeur</h4>
                <h6>(Au sens de l’article 93-2 de la loi n° 82-652 du 29 juillet 1982)</h6>
                Monsieur Fares SEMMAH.</br></br>
                </p>
                <p>
                <h4>Prestataire d’hébergement</h4>
                Pour fares-king.com</br>
                IONOS</br>
                7 Place de la Gare</br>
                57200 Sarreguemines - France</br>
                <a href="https://www.ionos.com/">Site hébergé sur IONOS.</a></br></br>
                </p>
                <p>
                <h4>Logiciel utilisé</h4>
                Pour la réalisation du site, il a été utilisé le logiciel de codage Microsoft Visual Studio</br></br>
                </p>
                <p>
                <h4>Contact</h4>
                Pour me contacter : fares67240@gmail.com
                </p>
            </div>
        </div>
    </div>
</section>
<?php require_once './partials/footer.php'; ?>