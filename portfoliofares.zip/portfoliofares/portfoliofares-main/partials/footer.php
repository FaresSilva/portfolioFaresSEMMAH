<footer>
    <div id="nav_inf">
        <div class="zone clearfix">

            <div class="zone-debut">

                Copyrights &copy; 2022 Tous droits réservés par Fares SEMMAH <br>

                <div class="nav_inf-liens"><a href="mlegales.html">Mentions légales</a>

                </div>

            </div>
        </div>
</footer>

</div>

<div id="bouton-haut" class="icone-bouton-haut"></div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/functions.js"></script>
</body>


</html>