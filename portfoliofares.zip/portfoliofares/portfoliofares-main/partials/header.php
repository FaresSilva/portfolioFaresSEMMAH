<?php
/**
 * <?= ?> représente un echo pour du templating
*
* Variable if else donc si ma variable $page est égale à index.php je met la classe onglet actuel
* (couleur verte) sinon rien
* class="<?= $page === 'index.php' ? 'onglet-actuel' : '' ?>"
*/
?>
<!DOCTYPE html>
<html dir="ltr" lang="fr-FR">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="author" content="Fares SEMMAH" />
    <link rel="stylesheet" href="css/style.css" type="text/css" />
    <link
        href="https://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic"
        rel="stylesheet" type="text/css" /> <!-- deja expliqué -->
    <link rel="icon" href="images/sio.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Fares | <?= $title ?></title>
</head>

<div id="nav_sup">
    <div class="zone clearfix">
        <div class="zone-debut pas-de-margin-bottom clearfix">
            <div class="nav_sup-gauche">
                <ul class="sf-js-enabled clearfix" style="touch-action: pan-y;">
                    <li><a href="index.php">Accueil</a></li>
                    <li><a href="contact.php">Me contacter</a></li>
                </ul>
            </div>
        </div>
        <div class="zone-debut float-droite zone-fin clearfix pas-de-margin-bottom">
            <div id="nav_sup-droite">
                <ul>
                    <li>
                        <a href="https://www.facebook.com/Fares.Fares.184" class="anim-facebook" style="width: 40px;"
                            data-hover-width="114">
                            <span class="zone-icone">
                                <i class="icone-facebook"></i>
                            </span>
                            <span class="zone-texte-icone">
                                Facebook
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="https://twitter.com/59FaresFares" class="anim-twitter" style="width: 40px;"
                            data-hover-width="95">
                            <span class="zone-icone">
                                <i class="icone-twitter"></i>
                            </span>
                            <span class="zone-texte-icone">
                                Twitter
                            </span>
                        </a>
                    </li>
                    <li><a href="https://www.linkedin.com/in/kévin-Fares-58274a154/" class="anim-linkedin"
                            style="width: 40px;" data-hover-width="107"><span class="zone-icone"><i
                                    class="icone-linkedin"></i></s<span class="zone-texte-icone">Linkedin</span>pan></a>
                    </li>
                    <li><a href="mailto:FaresFares.59@hotmail.com?subject=Conctat" class="anim-email"
                            style="width: 40px;" data-hover-width="232"><span class="zone-icone"><i
                                    class="icone-email"></i></span><span
                                class="zone-texte-icone">FaresFares.59@hotmail.com</span></a></li>
                </ul>
            </div>
        </div>

    </div>
</div>
<header id="header" class="nav_int-entier">
    <div id="nav_int-zone">
        <div class="zone clearfix">
            <div id="nav_int-menureduit">
                <i class="icone-menu"></i>
            </div>
            <nav id="nav_int-menu" class="dark">
                <ul>
                    <li class="<?= $page === 'index.php' ? 'onglet-actuel' : '' ?>">
                        <a href="index.php">
                            <div>Accueil</div>
                        </a>
                    </li>
                    <li class="<?= $page === 'presentation.php' ? 'onglet-actuel' : '' ?>">
                        <a href="presentation.php">
                            <div>Qui suis-je ?</div>
                        </a>
                    </li>
                    <li class="<?= $page === 'formation.php' || $page === 'ppe4.php' ? 'onglet-actuel' : '' ?>">
                        <a href="#">
                            <div>Ma formation</div>
                        </a>
                        <ul>
                            <li>
                                <a href="formation.php">
                                    <div>Ma formation</div>
                                </a>
                            </li>
                            <li><a href="ppe4.php">
                                    <div>PPE 3</div>
                                </a></li>
                            <li><a href="ppe4.php">
                                    <div>PPE 4</div>
                                </a></li>
                        </ul>
                    </li>
                    <li class="<?= $page === 'stagesbts.php' ? 'onglet-actuel' : '' ?>">
                        <a href="stagesbts.php">
                            <div>Stage</div>
                        </a>

                    </li>
                    <li class="<?= $page === 'cv.php' ? 'onglet-actuel' : '' ?>"><a href="competence.php">
                            <div>Compétences</div>
                        </a></li>
                    <li><a href="cv.php">
                            <div>CV</div>
                        </a></li>
                    <li class="<?= $page === 'veille.php' || $page === 'sveille.php' ? 'onglet-actuel' : '' ?>">
                        <a href="#">
                            <div>Veille technologique</div>
                        </a>
                        <ul>
                            <li><a href="veille.php">
                                    <div>Le cloud Computing</div>
                                </a></li>
                            <li><a href="sveille.php">
                                    <div>Sources</div>
                                </a></li>
                        </ul>
                    </li>

                </ul>
            </nav>
        </div>
    </div>
</header>