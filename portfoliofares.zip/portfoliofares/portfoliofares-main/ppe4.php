﻿<?php 
$page = basename(__FILE__);
// A compléter
$title = '';
require_once './partials/header.php'; 
?>

<section id="en-tete-page">
    <div class="zone clearfix">
        <h1>PPE 3 ET 4</h1>
    </div>
</section>


<section id="content">
    <div class="contenu-zone">
        <div class="zone clearfix">

            <h3 style="margin-bottom: 20px;" id="">Contexte :</h3>
            <p style="line-height: 1.42857143;">
                Dans le cadre de nos examens de fin d'année, j'ai réalisé <b>4 projets personnelles encadrées</b>.Ici je
                présenterai le 3ème projet qui m'a pris le plus de temps. Quant au <u>PPE 4</u>,
                la tâche qui m'incombai était, toujours pour la même entreprise de transformer mon site en application
                mobile. Ayant à l'avance préparer des web kit dans le code css, j'ai pû avec une Web view simplement
                utiliser cet fois mon site sous forme mobile.
                <br /><br />
            <div class="zone-milieu zone-fin pas-de-margin-bottom">
                <h3 id="">PPE3:</h3>
                </p>
                <br></br>
                <h2 id="">Présentation de la situation professionel:</h2>
                <p class="lineheight">
                    Le site web GSB Entreprise «Gestion de tickets » est accessible par tous.
                    Il a été developpé par moi et 2 collègues.<br />
                    <b>L'objectif</b> étant que ce site web permet aux utilisateurs, la création de ticket ou d’aide des
                    administrateurs.
                    Le <b>procésus de création du ticket </b> sera que l'utilisateur puisse créer son ticket, ajouter un
                    commentaire, se renseigner sur ses informations personnelles et détailler le ticket en question puis
                    enregistrer sa demande qui est transmise à une base de données, accessible par les administrateurs à
                    travers l’interface privée, qui eux ,pourront consulter le ticket et le clôturer ou même réouvrir.
                    L’utilisateur peut rajouter un commentaire à un ticket fermé si il a encore besoin d’aide.




                    <br /><br />
                </p>

                <p style="line-height: 1.42857143;">
                <h2 id="">Analyse et Préparation:</h2>
                <p style="line-height: 1.42857143;">Suite à la lecture du cahier des charges, nous avons déterminé les
                    éléments définissant les besoins des utilisateurs d’une part, et de l’autre des administrateurs.<br>
                    À partir de là, nous étions apte à mettre en place un diagramme de cas d’utilisation et un diagramme
                    de classe selon les données et paramètres recueillis qui nous permettait d’assurer le bon
                    déroulement du projet.
                </p>

                <h2 id=""> Cas d'utilisation: </h2>
                <p style="width: 100%; text-align: center; margin-top: 60px;">
                    <img class="cv" src="images/cas.jpg" width="900" height="1200" />
                </p>

                <h2 id=""> Modèle logique de données:</h2>
                <p style="width: 100%; text-align: center; margin-top: 60px;">
                    <img class="cv" src="images/donnees.jpg" />
                </p>

                <div>
                    5 Modules sont présents :<br>

                    <br><b>Module Accueil:</b>
                    <br> - Affichage de la page d’accueil
                    <br> - Affichage du statuts des tickets et de l’historique
                    <br> - Bouton Accueil ; Tickets ; Admin<br><br>

                    <br><b>Module Création de ticket:</b>
                    <br>- Saisie du titre du ticket, l’émail de l’utilisateur, du commentaire, de la priorité, privé ou
                    non et de la catégorie du ticket
                    <br>- Envoi du ticket<br><br>

                    <br><b>Module Consulter ses tickets:</b>
                    <br>- L’utilisateur peut consulter ses tickets
                    <br>- L’utilisateur peut ajouter des commentaires à ses tickets<br><br>


                    <br><b>Module Liste des tickets Admin:</b>
                    <br>- L’administrateur peut consulter tous les tickets de la BDD
                    <br>- L’administrateur peut clôturer ou rouvrir le ticket.<br><br>

                    <b>Deux statuts ont été définis:</b><br>
                    - Utilisateur<br>
                    - Administrateur

                    <br><br>Nous avons défini l’environnement de développement, de test et les différents outils et
                    technologies que nous allions utiliser pour ce développement:<br>
                    <br><b>Environnement de développement:</b>
                    <br>- Poste de travail Windows 10
                    <br>- MYSQL : BDD hébergé sur PhpMyAdmin
                    <br>- Visual Studio 2019 : éditeur de texte pour le code
                    <br>- Gestion de la BDD : PHPMyAdmin<br><br>

                    <b>Environnement de test:</b>
                    <br>- MYSQL WorkBench : BDD local crée avec PHPMyAdmin<br>

                    <div>
                        <h4 class="list-title-style">
                            <b>Langages:</b>
                        </h4>
                        <ul class="liste-style">
                            <li>CSS</li>
                            <li>PHP</li>
                            <li>HTML</li>
                            <li>SQL</li>
                            <li>JavaScript</li>
                        </ul>
                    </div>
                    <div>
                        <h4 class="list-title-style">
                            <b>Rédaction des documents:</b>
                        </h4>
                        <ul class="liste-style">
                            <li>Microsoft Word Office</li>
                        </ul>
                    </div>
                </div>

                <h2>Captures d'écran</h2>
                <h4>Interface Login Utilisateur:</h4>
                <p style="width: 100%; text-align: center; margin-top: 60px;">
                    <img class="cv" src="images/login.jpg" />
                </p>

                <h4>Interface Accueil:</h4>
                <p style="width: 100%; text-align: center; margin-top: 60px;">
                    <img class="cv" src="images/accueil.jpg" />
                </p>

                <h4>Interface Tickets:</h4>
                <p style="width: 100%; text-align: center; margin-top: 60px;">
                    <img class="cv" src="images/tickets.jpg" />
                </p>

                <h4>Interface Tickets Admin:</h4>
                <p style="width: 100%; text-align: center; margin-top: 60px;">
                    <img class="cv" src="images/ticketsadmin.jpg" />
                </p>

                <h4>Extraits Code:</h4>
                <p style="width: 100%; text-align: center; margin-top: 60px;">
                    <img class="cv" src="images/code1.jpg" />
                </p>

                <p style="width: 100%; text-align: center; margin-top: 60px;">
                    <img class="cv" src="images/code2.jpg" />
                </p>
            </div>

        </div>
    </div>
</section>
<?php require_once './partials/footer.php'; ?>