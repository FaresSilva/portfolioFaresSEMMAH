﻿<?php 
$page = basename(__FILE__);
// A compléter
$title = '';
require_once './partials/header.php'; 
?>

<section id="en-tete-page">
    <div class="zone clearfix">
        <h1>Qui Suis-Je ?</h1>
    </div>
</section>

<section id="content">
    <div class="contenu-zone">
        <div class="zone clearfix">
            <div class="zone-milieu zone-fin pas-de-margin-bottom">
                <p>
                <h3 id="moi" style="text-align: center;">Qui suis-je ?</h3>
                </p><br />
                <p>
                <div style="text-indent: 30px;">
                    J’ai 19 ans, et je suis avant tout passionné par l’informatique.
                    Très curieux de nature et logique, j’aime comprendre le fonctionnement des choses.
                    C’est pourquoi je suis attiré de longue date par l’électronique et l’informatique.
                    Je suis dynamique, sérieux et méthodique dans tous les domaines qui me passionnent et ma curiosité
                    m’amène sans cesse à repousser mes limites pour progresser.
                    J’aime aussi voyager, la mode et rester à jour sur l’actualité.
                </div>
                </p>
                <p>
                <h3 id="parcours" style="text-align: center;">Mon parcours</h3>
                </p><br />
                <p>
                <div style="text-indent: 30px;">
                    Après ma classe de Seconde Générale, j’ai choisi d’aller en 1ère année de Sciences et Technologies
                    de l’Industrie du Développement Durable (STI2D) avec l’option Système Informatique et Numérique (
                    SIN ) dû à mon intérêt pour l’informatique depuis déjà tout jeune.
                    Après l’obtention de ce diplôme, j’ai intégré le BTS SIO (Services Informatiques aux organisations)
                    option SLAM ( Services informatiques aux organisations solutions logicielles et applications
                    métiers).Même si j’ai effectué un diplôme axée développement web/logiciel, ma première s’est porté
                    quasiment que sur le réseau, ce qui rend mon diplôme si spéciale. Et le second avantage que je tire
                    de ce Bac+2 et que j’ai bénéficié d’un pôle économique-managériale et juridique qui m’est réellement
                    utile principalement pour la gestion économique d’un parc informatique par exemple ou pour l’aspect
                    juridique de la cybersécurité
                    J’ai choisi l’enseignement professionnel car l’expérience acquise lors des stages est très appréciée
                    par les employeurs.

                </div>
                </p>
                <p>
                <h3 id="objectif" style="text-align: center;">Mes objectifs professionnels</h3>
                </p><br />
                <p>
                <div style="text-indent: 30px;">
                    Je souhaite intégrer une licence professionnelle CDAISI (Cyber Défense, Anti-Intrusion des Systèmes
                    d’Information) ou plus globalement une licence accès cyber sécurité dès la rentrée universitaire
                    2021 après l’obtention de mon BTS SIO. En effet, mon stage en milieu professionnel et mon entourage
                    professionnel m’ont fait prendre conscience que la priorité actuelle des entreprises est la volonté
                    de sécuriser leurs réseaux informatiques pour garantir la confidentialité des données et le bon
                    fonctionnement des systèmes. Fort de cette constatation et conscient des débouchés actuels de cette
                    formation, je souhaite donc me spécialiser dans ce domaine. Suite à cette licence, je souhaite
                    travailler en tant qu’architecte réseau spécialisé dans la cyber sécurité et les systèmes
                    anti-intrusion informatiques.
                </div>
                </p>
            </div>
        </div>
    </div>
</section>
<?php require_once './partials/footer.php'; ?>