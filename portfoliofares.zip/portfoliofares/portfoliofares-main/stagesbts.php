﻿<?php 
$page = basename(__FILE__);
// A compléter
$title = '';
require_once './partials/header.php'; 
?>

<section id="en-tete-page">
    <div class="zone clearfix">
        <h1>Stage durant le BTS SIO</h1>
    </div>
</section>

<section id="content">
    <div class="contenu-zone">
        <div class="zone clearfix">
            <div class="zone-milieu zone-fin pas-de-margin-bottom">
                <p>
                <h3 id="StageBTS">Stage durant le BTS SIO</h3>
                </p><br />
                <p>
                <div>
                    J’ai effectué mon stage de première année de BTS SIO au sein de l'entreprise, OPINAKA basée à
                    Montpellier en télétravail. <br> Je précise que j'ai dû annuler mon stage de première année <b>
                        faute au COVID</b>. <br /><br />
                </div>
                </p>
                <p>
                <h3 id="entreprise" style="text-align: center;">Présentation de l’entreprise</h3>
                </p><br />
                <p>
                <div style="text-indent: 30px;">
                    Période : du <b>9/11/2020</b> au <b>04/12/2020</b> soit 1 mois.<br /><br />

                    Cette société est spécialisée dans quatre domaines liés à l’informatique :<br /><br />
                    <div class="indent">
                        - L’informatique au sens large (audit, conseil, vente et formation),<br />
                        - L’assistance (par téléphone ou sur site) et la maintenance en SAV (service après-vente),<br />
                        - L’aide aux particuliers (architecture réseau, intégration et développement, sécurité et
                        services internet, déploiement de site)<br /><br>

                    </div>

                    Les différents services proposés par la société s’appliquent aussi bien aux particuliers qu’aux
                    entreprises et les techniciens interviennent dans les locaux des entreprises clientes, chez les
                    particuliers mais également dans l’atelier de SAV de la société.</b><br /><br />
                </div>
                </p>
                </br>
                </br>
            </div>
        </div>
    </div>
</section>

<?php require_once './partials/footer.php'; ?>