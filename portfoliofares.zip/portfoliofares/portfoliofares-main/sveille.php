﻿<?php 
$page = basename(__FILE__);
// A compléter
$title = '';
require_once './partials/header.php'; 
?>

<section id="slider" class="amin-multi-slider inter-slider-toucher largeur-max clearfix">
    <div class="amin-multi-slider-inter">
        <div class="zone-slider-toucher zone-slider-toucher-parent">
            <div class="zone-interne-slider">
                <div class="zone-slider style-menu" style="background-image: url('images/slider/slider3.jpg')">
                    <div class="zone clearfix">
                        <div class="zone-text-amin-slider zone-text-amin-slider-centre text-slider">
                            <h2 style="color: #EEE; font-size:54px;" class="text-slider-tel"
                                data-caption-animate="amination-slider-haut">
                                Réduire le risque du cloud computing
                            </h2>
                            <p style="color: #EEE;" data-caption-animate="amination-slider-haut"
                                data-caption-delay="200">
                            <ol class="nav_page-liste slider-text">
                                <li><a href="http://www.zdnet.fr/actualites/reduire-le-risque-du-cloud-computing-39850138.htm"
                                        style="color: #EEE;">En savoir plus</a></li>
                            </ol>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="zone-slider style-menu" style="background-image: url('images/slider/slider5.jpg')">
                    <div class="zone clearfix">
                        <div class="zone-text-amin-slider zone-text-amin-slider-centre text-slider">
                            <h2 style="color: #EEE; font-size:54px;" class="text-slider-tel"
                                data-caption-animate="amination-slider-haut">
                                Sieve, ultime système de contrôle d'accès aux données privées
                            </h2>
                            <p style="color: #EEE;" data-caption-animate="amination-slider-haut"
                                data-caption-delay="200">
                            <ol class="nav_page-liste slider-text">
                                <li><a href="http://www.lemondeinformatique.fr/actualites/lire-sieve-ultime-systeme-de-controle-d-acces-aux-donnees-privees-64270.html"
                                        style="color: #EEE;">En savoir plus</a></li>
                            </ol>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="zone-slider style-menu" style="background-image: url('images/slider/slider4.jpg')">
                    <div class="zone clearfix">
                        <div class="zone-text-amin-slider zone-text-amin-slider-centre text-slider">
                            <h2 style="color: #EEE; font-size:54px;" class="text-slider-tel"
                                data-caption-animate="amination-slider-haut">
                                Cloud public : 21,5% de croissance annuelle du marché jusqu'en 2020
                            </h2>
                            <p style="color: #EEE;" data-caption-animate="amination-slider-haut"
                                data-caption-delay="200">
                            <ol class="nav_page-liste slider-text">
                                <li><a href="http://www.zdnet.fr/actualites/cloud-public-215-de-croissance-annuel-du-marche-jusqu-en-2020-39848876.htm"
                                        style="color: #EEE;">En savoir plus</a></li>

                            </ol>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div id="anim-fleche-gauche"><i class="icone-fleche-gauche"></i></div>
            <div id="anim-fleche-droite"><i class="icone-fleche-droite"></i></div>
        </div>
        <a href="#cloud" data-scrollto="#content" data-offset="100" class="style-menu fleche-bas"><i
                class="icone-fleche-bas infinite animated amination-slider-bas"></i></a>
    </div>
</section>

<section id="content">
    <div class="contenu-zone">
        <div class="zone clearfix">
            <div class="zone-milieu zone-fin pas-de-margin-bottom">
                <h3 id="sources">Cloud Computing - Sources</h3>

                <p style="margin-top: 55px;">
                <h4>Réduire le risque du cloud computing</h4>
                Le 21/03/17<br /><br />
                Les études dans leur ensemble montrent une forte hausse de l'adoption du cloud computing, notamment
                hybride : selon un récent rapport, 95 % des professionnels de l'informatique disent utiliser le cloud et
                75 % le cloud computing hybride. Ce rapport montre également que la sécurité n'est plus le principal
                défi lié au cloud, la place étant désormais occupée par le manque de ressources et
                d'expertise<br /><br />
                <ol class="bouton_rapport">
                    <li><a href="http://www.zdnet.fr/actualites/reduire-le-risque-du-cloud-computing-39850138.htm">En
                            savoir plus ...</a></li>
                </ol>
                </p>

                <p>
                <h4>L'avenir du cloud computing est vertical</h4>
                Le 07/03/17<br /><br />
                Lorsque les premiers services de cloud computing sont apparus et pendant une longue période après cela,
                les prestataires de services de cloud computing se sont concentrés assez naturellement sur les
                opportunités les plus faciles à saisir. Leur terrain de jeu était centré sur des applications
                essentielles mais génériques, telles que la messagerie électronique, la productivité bureautique et le
                stockage, qui sont rapidement devenues les premières à être transférées dans le cloud.<br /><br />
                <ol class="bouton_rapport">
                    <li><a href="http://www.zdnet.fr/actualites/l-avenir-du-cloud-computing-est-vertical-39849474.htm">En
                            savoir plus ...</a></li>
                </ol>
                </p>

                <p>
                <h4>Utilisation du cloud comme plate-forme pour l'innovation</h4>
                Le 27/03/17<br /><br />
                La menace de perturbation signifie que les DSI et leurs homologues dirigeants subissent une pression
                plus forte que jamais pour développer des solutions créatives aux problèmes de l'entreprise.<br /><br />
                <ol class="bouton_rapport">
                    <li><a
                            href="http://www.zdnet.fr/actualites/utilisation-du-cloud-comme-plate-forme-pour-l-innovation-39848978.htm">En
                            savoir plus ...</a></li>
                </ol>
                </p>

                <p>
                <h4>Cloud public : 21,5% de croissance annuelle du marché jusqu'en 2020</h4>
                Le 22/03/17<br /><br />
                Les dépenses en matière de services de cloud public dans le monde devraient atteindre 122,5 milliards de
                dollars en 2017 affirme le cabinet de recherche IDC. Soit une augmentation de 24,4% par rapport à
                2016.<br /><br />
                <ol class="bouton_rapport">
                    <li><a
                            href="http://www.zdnet.fr/actualites/cloud-public-215-de-croissance-annuel-du-marche-jusqu-en-2020-39848876.htm">En
                            savoir plus ...</a></li>
                </ol>
                </p>

                <p>
                <h4>IaaS : AWS plus grand qu'IBM, Google et Microsoft réunis</h4>
                Le 07/02/17<br /><br />
                Amazon Web Services (AWS) représente à lui seul un tiers du marché du Cloud d'infrastructure : plus que
                le chiffre d'affaires dégagé par ses trois principaux concurrents réunis.<br /><br />
                <ol class="bouton_rapport">
                    <li><a
                            href="http://www.zdnet.fr/actualites/iaas-aws-plus-grand-qu-ibm-google-et-microsoft-reunis-39848232.htm">En
                            savoir plus ...</a></li>
                </ol>
                </p>

                <p>
                <h4>Quand le cloud rime avec vérifications des identités</h4>
                Le 16/01/17<br /><br />
                Longtemps réservée aux fonctions régaliennes de contrôle des populations, la vérification des identités
                joue un rôle de plus en plus important dans de nombreux services privés, comme ceux de type bancaire.
                Avec le développement du cloud et des connexions mobiles, elle se fait désormais à la volée au sein même
                des applications.<br /><br />
                <ol class="bouton_rapport">
                    <li><a
                            href="http://www.zdnet.fr/actualites/quand-le-cloud-rime-avec-verifications-des-identites-39847220.htm">En
                            savoir plus ...</a></li>
                </ol>
                </p>

                <p>
                <h4>Comment le cloud computing peut rendre les robots plus intelligents et plus performants</h4>
                Le 13/12/16<br /><br />
                Qu'arrive-t-il lorsque vous mélangez cloud computing et robotique ? Vous obtenez des robots plus
                puissants et plus intelligents, capables de collaborer et de communiquer entre eux pour tirer des
                enseignements de leurs erreurs respectives, de sorte à pouvoir réaliser diverses tâches plus
                efficacement.<br /><br />
                <ol class="bouton_rapport">
                    <li><a
                            href="http://www.zdnet.fr/actualites/comment-le-cloud-computing-peut-rendre-les-robots-plus-intelligents-et-plus-performants-39845874.htm">En
                            savoir plus ...</a></li>
                </ol>
                </p>

                <p>
                <h4>Cloud public : 17,2 % de croissance cette année</h4>
                Le 15/09/17<br /><br />
                Le marché du cloud public est en croissance de 17,2 % cette année affirme le Gartner. Le volume total de
                ce marché était de 178 milliards de dollars en 2015, il est de 208,6 milliards de dollars en
                2016.<br /><br />
                <ol class="bouton_rapport">
                    <li><a
                            href="http://www.zdnet.fr/actualites/cloud-public-172-de-croissance-cette-annee-39841970.htm">En
                            savoir plus ...</a></li>
                </ol>
                </p>

                <p>
                <h4>Cloud souverain : les collectivités locales ne pourront pas y couper</h4>
                Le 07/06/16<br /><br />
                Mieux vaut tard que jamais : une circulaire parue au Journal officiel et signée par la direction
                générale des collectivités locales et le service interministériel des Archives de France vient clarifier
                les dispositions relatives au « cloud souverain ». Le texte, repéré par NextInpact, explique que les
                collectivités françaises devront impérativement passer par des prestataires situés sur le territoire
                français pour stocker et traiter les données dans le cloud.<br /><br />
                <ol class="bouton_rapport">
                    <li><a
                            href="http://www.zdnet.fr/actualites/cloud-souverain-les-collectivites-locales-ne-pourront-pas-y-couper-39837976.htm">En
                            savoir plus ...</a></li>
                </ol>
                </p>

                <p>
                <h4>La sécurité d'Office 365 et Azure monte d'un cran</h4>
                Le 26/02/16<br /><br />
                En annonçant l'arrivée prochaine de Cloud App Security et d'Azure Active Directory Identity Protection,
                Microsoft espère bien rassurer les utilisateurs de ses solutions cloud face à l'explosion des
                menaces.<br /><br />
                <ol class="bouton_rapport">
                    <li><a
                            href="http://www.lemondeinformatique.fr/actualites/lire-la-securite-d-office-365-et-azure-monte-d-un-cran-64048.html">En
                            savoir plus ...</a></li>
                </ol>
                </p>

                <p>
                <h4>Microsoft synchronise les terminaux Windows 10 via Azure AD</h4>
                Le 09/02/16<br /><br />
                Un utilisateur pouvait déjà synchroniser les paramètres de ses différents terminaux Windows en passant
                par son compte Microsoft dans le cloud et par OneDrive. Cette synchronisation entre postes de travail
                peut désormais se faire dans l'entreprise avec Windows 10 en respectant les exigences de contrôle et de
                sécurité de la DSI. Le service Enterprise State Roaming est pour l'instant disponible en préversion
                publique, notamment en Europe.<br /><br />
                <ol class="bouton_rapport">
                    <li><a
                            href="http://www.lemondeinformatique.fr/actualites/lire-microsoft-synchronise-les-terminaux-windows-10-via-azure-ad-63858.html">En
                            savoir plus ...</a></li>
                </ol>
                </p>

                <p>
                <h4>Azure Stack apporte sur site les outils du cloud Microsoft</h4>
                Le 28/02/16<br /><br />
                Avec Azure Stack, qui sort en préversion technique, Microsoft propose d'utiliser sur site les mêmes
                outils de développement et d'administration que pour son cloud public.<br /><br />
                <ol class="bouton_rapport">
                    <li><a
                            href="http://www.lemondeinformatique.fr/actualites/lire-azure-stack-apporte-sur-site-les-outils-du-cloud-microsoft-63730.html">En
                            savoir plus ...</a></li>
                </ol>
                </p>

                <p>
                <h4>Sieve, ultime système de contrôle d'accès aux données privées</h4>
                Le 21/03/16<br /><br />
                Des chercheurs du MIT et d'Harvard ont mis au point le logiciel Sieve permettant de stocker dans le
                cloud de façon chiffrée toutes sortes de données privées. Pour être exploitées par un tiers, un système
                de clé chiffrée éphémère a été conçu.<br /><br />
                <ol class="bouton_rapport">
                    <li><a
                            href="http://www.lemondeinformatique.fr/actualites/lire-sieve-ultime-systeme-de-controle-d-acces-aux-donnees-privees-64270.html">En
                            savoir plus ...</a></li>
                </ol>
                </p>






            </div>
        </div>
    </div>
</section>
<?php require_once './partials/footer.php'; ?>