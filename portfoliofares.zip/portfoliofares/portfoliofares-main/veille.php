﻿<?php 
$page = basename(__FILE__);
// A compléter
$title = '';
require_once './partials/header.php'; 
?>

<section id="slider" class="amin-multi-slider inter-slider-toucher largeur-max clearfix">
    <div class="amin-multi-slider-inter">
        <div class="zone-slider-toucher zone-slider-toucher-parent">
            <div class="zone-interne-slider">
                <div class="zone-slider style-menu" style="background-image: url('images/slider/slider2.jpg')">
                    <div class="zone clearfix">
                        <div class="zone-text-amin-slider zone-text-amin-slider-centre">
                            <h2 style="color: black;" data-caption-animate="amination-slider-haut">
                                <a style="color: #EEE" href="#cloud">La Crypto-Monnaie</a>
                            </h2>
                            <p style="color: black;" data-caption-animate="amination-slider-haut"
                                data-caption-delay="200">
                            <ol class="nav_page-liste slider-tel">
                                <li><a href="#intro" style="color: #EEE;">Qu'est ce que la Crypto-Monnaie ?</a></li>
                                <li><a href="#fonction" style="color: #EEE;">Son fonctionnement</a></li>
                                <li><a href="#serv" style="color: #EEE;">Les services proposés</a></li>
                                <li><a href="#hist" style="color: #EEE;">L’histoire de la Crypto-Monnaie</a></li>
                                <li><a href="#cons" style="color: #EEE;">Les conséquences</a></li>
                                <li><a href="#avan" style="color: #EEE;">Ses avantages</a></li>
                                <li><a href="#incon" style="color: #EEE;">Ses inconvénients</a></li>
                            </ol>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <a href="#cloud" data-scrollto="#content" data-offset="100" class="style-menu fleche-bas"><i
                class="icone-fleche-bas infinite animated amination-slider-bas"></i></a>
    </div>
</section>

<div id="nav_page-slider">
    <ol class="nav_page-liste">
        <li><a href="#intro">Qu'est ce que la Crypto-Monnaie ?</a></li>
        <li><a href="#fonction">Son fonctionnement</a></li>
        <li><a href="#serv">Les services proposés</a></li>
        <li><a href="#hist">L’histoire de la Crypto-Monnaie</a></li>
        <li><a href="#cons">Les conséquences</a></li>
        <li><a href="#avan">Ses avantages</a></li>
        <li><a href="#incon">Ses inconvénients</a></li>
    </ol>
</div>

<section id="content">
    <div class="contenu-zone">
        <div class="zone clearfix">
            <div class="zone-milieu zone-fin pas-de-margin-bottom">
                <h2 id="cloud">La Crypto-Monnaie</h2>
                <h3 id="intro">Qu'est ce que la Crypto-Monnaie ?</h3>
                <div>
                    <p>
                        Nous connaissons tous le principe d’une monnaie classique, ce système de paiement matérialisé
                        par des pièces, des Euros dans notre cas.
                        <br>Une crypto monnaie est un moyen de paiement, servant à réaliser des transactions au même
                        type qu’une monnaie classique type dollar ou euro.
                        <br>La particularité d’une crypto monnaie se joue sur le fait que celle-ci est décentralisée,
                        elle n’est indexée sur aucun cours, et n'appartient à aucune banque.
                        <br />
                        <br>
                    </p>
                </div>

                <h3 id="fonction">Son fonctionnement</h3>
                <p>
                    Pour sécuriser les transactions entre utilisateurs, une crypto monnaie utilise un réseau
                    d’ordinateurs maillés entre eux appelés “Blockchain”.
                    <br>Lorsqu’une transaction est effectuée, celle-ci est consignée sur une grande base de données
                    mondiale.
                    <br>Cette base de donnée est architecturée sous forme de “blocs”, chaque blocs contient une
                    transaction, les reliés ensemble sont donc appelés chaîne de blocs, donnant son nom iconique à la
                    “blockchain”.<br />
                    <br>
                </p>
            </div>

            <h3 id="serv">Les services proposés</h3>
            <div style="text-indent: 30px;">
                <p>
                <h4 style="font-size: 14px; text-indent: 0px;">Deux principaux services utilisés pour acquérir de la
                    crypto-monnaie:</h4>
                <h5><b>Achat</b>:</h5>
                <div class="indent">
                    <p>
                        La première méthode est d’en acheter en ligne, à l’aide de sites spécialisés dans l’achat, ainsi
                        que la revente de crypto-monnaies, tels que Binance ou Kraken.
                        <br>Il est très facile d’acheter une crypto monnaie, cependant certaines sont soumises à des
                        conditions d’achat minimum, par exemple certaines crypto monnaies vous demanderont d’acheter un
                        minimum de 25 euros.
                    </p>
                </div>

                <h4><b>Minage</b>:</h4>
                <div class="indent">
                    <p>
                        La seconde méthode, moins utilisée car elle demande plus de ressources est de “miner” une crypto
                        monnaie.
                        <br>Un mineur va se charger d’executer un logiciel chargé d’utiliser l’entière ressource de son
                        ordinateur pour pouvoir vérifier et valider les transactions d’un bloc pour pouvoir ensuite
                        ajouter celui-ci à la blockchain, et ainsi pouvoir gagner une certaine somme en crypto monnaie,
                        qui varrieras en fonction de la puissance de calcul de l’ordinateur.
                    </p>
                </div>
                <br>
                </p>
            </div>

            <h3 id="hist">L’histoire de la Crypto-Monnaie</h3>
            <div>
                <p>
                    Ce qui a fait connaître mondialement les crypto-monnaies et les a propulsées à une telle échelle est
                    l’histoire du Bitcoin, la monnaie virtuelle la plus connue à ce jour, coûtant à l’heure actuelle
                    environ 30 000 euros le bitcoin, à l’unité.
                    <br>Le bitcoin fut créé en 2009 par une mystérieuse personne anonyme (qui pourrait être également un
                    groupe de personnes) répondant sous le pseudonyme de “Satoshi Nakamoto”.
                    <br>Depuis 2011, le bitcoin connaît une forte expansion, qui n’est pas prête de s’arrêter.
                    Cependant, le Bitcoin n’est pas la première crypto-monnaie a avoir fait son apparition. <br>
                    <br>C’est en 1989 que DigiCash, une entreprise fondée dans le but de pouvoir créer la première
                    monnaie virtuelle par David Chaum fit son apparition, nous retiendrons cependant l’histoire du
                    Bitcoin, beaucoup plus impactante.<br /><br />
                </p>
            </div>


            <h3 id="cons">Les conséquences</h3>
            <div>
                <p>
                    Les crypto-monnaies commencent à avoir des conséquences sur l’économie dans le monde, la Chine par
                    exemple a annoncé avoir banni le Bitcoin, la plus grande monnaie virtuelle, suite à sa croissance
                    exponentielle hors norme.
                    <br><br>La seconde conséquence concerne les banques. De plus en plus de personnes délaissent les
                    banques suite à la liberté fournie par les monnaies virtuelles qui ne sont pas tracées, et indexées
                    sur aucun cours.
                </p>
            </div>

            <h3 id="avan">Ses avantages</h3>
            <div>
                <p>
                    La crypto-monnaie possède de nombreux avantages, séduisants ses nouveaux utilisateurs:<br>

                    <br>- Celle-ci n’est soumise à aucune autorité (aucun interdit bancaire, transactions instantanées,
                    pas de plafonds)
                    <br>- Son système est entièrement indépendant et décentralisé
                    <br>- Elle possède son historique complet de transactions
                    <br>- L’utilisateur possède son un contrôle total sur son argent
                </p>
            </div>

            <h3 id="incon">Ses inconvénients</h3>
            <div>
                <p>
                    Cependant la crypto-monnaie possède deux inconvénients majeurs, qui sont une utilisation peu majeure
                    par l'entièreté de la société, ainsi que son peu de régulation, ce qui augmente le risque
                    d’arnaques.
                </p>
            </div>
        </div>
    </div>
    </div>
</section>

<?php require_once './partials/footer.php'; ?>